package com.CeylonSpehere.TravelApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
