package com.CeylonSpehere.TravelApp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadDocumentsDTO {
    private String passportBioPage;
    private String invitationLetter;
    private String additionalDocuments;
}
