package com.CeylonSpehere.TravelApp.dto.requestDto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RequestDestinationDto {

    private String dest_id;

    private String dest_name;

    private String description;

    private String geolocation;
}
