package com.CeylonSpehere.TravelApp.controller;

import com.CeylonSpehere.TravelApp.dto.UserDTO;
import com.CeylonSpehere.TravelApp.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/identity")
@AllArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestParam String email, @RequestParam String password) {
        return new ResponseEntity<>(userService.login(email, password), HttpStatus.OK);
    }

    @PostMapping("/user")
    public void createUser(@RequestBody UserDTO userDTO) {
        userService.create(userDTO);
    }

    @PutMapping("/reset-password/init-otp")
    public void initRestPasswordOTP(@RequestParam String email) {
        userService.initForgotPassword(email);
    }

    @PutMapping("/reset-password/verify-otp")
    public void verifyRestPasswordOTP(@RequestParam String email, @RequestParam String otp) {
        userService.verifyForgotPasswordOTP(email, otp);
    }

    @PutMapping("/reset-password/reset")
    public void resetPassword(@RequestParam String email, @RequestParam String password) {
        userService.resetUserPassword(email, password);
    }

}
