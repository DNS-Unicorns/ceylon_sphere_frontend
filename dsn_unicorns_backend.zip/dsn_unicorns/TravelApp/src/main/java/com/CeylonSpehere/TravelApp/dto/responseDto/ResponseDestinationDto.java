package com.CeylonSpehere.TravelApp.dto.responseDto;

public class ResponseDestinationDto {

}
