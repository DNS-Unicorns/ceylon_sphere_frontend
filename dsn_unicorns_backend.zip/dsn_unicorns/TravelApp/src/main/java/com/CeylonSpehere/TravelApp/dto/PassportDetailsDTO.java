package com.CeylonSpehere.TravelApp.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class PassportDetailsDTO {
    private String passportNumber;
    private String issuingCountry;
    private LocalDate passportIssueDate;
    private LocalDate passportExpiryDate;
    private String placeOfIssue;
    private String passportType;
}
