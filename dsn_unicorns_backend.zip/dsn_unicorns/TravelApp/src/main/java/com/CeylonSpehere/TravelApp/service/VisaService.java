package com.CeylonSpehere.TravelApp.service;

import com.CeylonSpehere.TravelApp.dto.*;

import java.util.List;

public interface VisaService {
    void saveEligibilityCriteria(EligibilityCriteriaDTO eligibilityCriteriaDTO);

    void saveUploadDocuments(UploadDocumentsDTO uploadDocumentsDTO);

    void savePassportDetails(PassportDetailsDTO passportDetailsDTO);

    void saveContactDetails(ContactDetailsDTO contactDetailsDTO);

    void saveAdditionalDetails(AdditionalDetailsDTO additionalDetailsDTO);

    VisaApplicationDTO getVisaApplication();

    List<VisaApplicationDTO> getAllPendingVisaApplications();
    void approveVisaApplication(Long applicationId);
    void rejectVisaApplication(Long applicationId, String rejectionReason);
}
