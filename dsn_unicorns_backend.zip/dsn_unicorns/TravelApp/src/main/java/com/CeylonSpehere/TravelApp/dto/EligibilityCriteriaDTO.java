package com.CeylonSpehere.TravelApp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EligibilityCriteriaDTO {
    private String nationality;
    private String countryOfResidence;
    private String visaType;
    private String visaCategory;
    private String purposeOfTravel;
    private String subVisaType;
    private String typeOfTravelDocument;
}
