package com.CeylonSpehere.TravelApp.controller;

public class DestinationController {
}
