package com.CeylonSpehere.TravelApp.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class AdditionalDetailsDTO {
    private LocalDate dateOfArrivalInSriLanka;
    private String portOfEntry;
    private String placeOfStayDuringVisit;
    private LocalDate proposedDepartureDate;
    private String addressLine1;
    private String city;
    private String state;
    private String zipCode;
    private String contactCountryCode;
    private String contactNumberInSriLanka;
}
