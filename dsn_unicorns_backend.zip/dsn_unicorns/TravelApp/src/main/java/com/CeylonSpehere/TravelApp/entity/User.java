package com.CeylonSpehere.TravelApp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity(name = "application_user")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class User extends BaseEntity {
    @Column(length = 100, nullable = false)
    private String email;

    @Column(length = 15, nullable = false)
    private String country;

    @Column(nullable = false)
    private String role;

    private String userFavourites;
    private String identityId;
}
