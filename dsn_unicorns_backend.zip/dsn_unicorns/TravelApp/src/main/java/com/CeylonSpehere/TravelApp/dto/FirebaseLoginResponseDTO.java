package com.CeylonSpehere.TravelApp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FirebaseLoginResponseDTO {
    private String idToken;
    private String refreshToken;
    private String expiresIn;
    private String localId;
}
