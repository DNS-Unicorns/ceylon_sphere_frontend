package com.CeylonSpehere.TravelApp.repository;

import com.CeylonSpehere.TravelApp.entity.OTP;
import com.CeylonSpehere.TravelApp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OTPRepository extends JpaRepository<OTP, Long> {
    Optional<OTP> findFirstByOtpAndUserIdOrderByIdDesc(String otp, Long userId);
}
