package com.CeylonSpehere.TravelApp.service.impl;

import com.CeylonSpehere.TravelApp.client.FirebaseAuthClient;
import com.CeylonSpehere.TravelApp.dto.FirebaseLoginRequestDTO;
import com.CeylonSpehere.TravelApp.dto.FirebaseLoginResponseDTO;
import com.CeylonSpehere.TravelApp.dto.UserDTO;
import com.CeylonSpehere.TravelApp.entity.OTP;
import com.CeylonSpehere.TravelApp.entity.User;
import com.CeylonSpehere.TravelApp.repository.OTPRepository;
import com.CeylonSpehere.TravelApp.repository.UserRepository;
import com.CeylonSpehere.TravelApp.service.EmailService;
import com.CeylonSpehere.TravelApp.service.UserService;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.UserRecord;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private final String FIREBASE_API_KEY = "AIzaSyChKWCcF9mTTGclTvrzx9UbSviHjbqjno0";
    private final UserRepository userRepository;
    private final FirebaseAuthClient firebaseAuthClient;
    private final EmailService emailService;
    private final OTPRepository otpRepository;
    private final ModelMapper modelMapper;

    @Override
    public String login(String username, String password) {
        FirebaseLoginRequestDTO firebaseLoginRequestDTO = new FirebaseLoginRequestDTO(username, password, true);
        FirebaseLoginResponseDTO firebaseLoginResponseDTO = firebaseAuthClient.signInWithPassword(FIREBASE_API_KEY, firebaseLoginRequestDTO);
        return firebaseLoginResponseDTO.getIdToken();
    }

    @Override
    public void create(UserDTO userDTO) {
        try {
            User existingUser = userRepository.findByEmail(userDTO.getEmail());
            if (existingUser != null) {
                throw new RuntimeException();
            }

            UserRecord.CreateRequest request = new UserRecord.CreateRequest()
                    .setEmail(userDTO.getEmail())
                    .setPassword(userDTO.getPassword());
            UserRecord user = FirebaseAuth.getInstance().createUser(request);
            Map<String, Object> claims = new HashMap<>();
            claims.put("role", "External");
            FirebaseAuth.getInstance().setCustomUserClaims(user.getUid(), claims);

            User dbUser = modelMapper.map(userDTO, User.class);
            dbUser.setRole("External");
            dbUser.setIdentityId(user.getUid());
            userRepository.save(dbUser);
        } catch (FirebaseAuthException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void initForgotPassword(String email) {
        User user = userRepository.findByEmail(email);
        if (user != null) {
            throw new RuntimeException();
        }

        OTP otp = new OTP();
        otp.setUser(user);
        otp.setUsed(false);
        otp.setOtp(generateRandomOTP().toString());
        otpRepository.save(otp);

        String emailBody = String.format("""
                Dear User

                Please use this %s OTP to update your password.

                TravelAPP Team""", otp.getOtp());

        emailService.sendEmail(email, "Reset Password OTP", emailBody);
    }

    @Override
    public void verifyForgotPasswordOTP(String email, String otp) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new RuntimeException();
        }


        Optional<OTP> optionalOTP = otpRepository.findFirstByOtpAndUserIdOrderByIdDesc(otp, user.getId());
        if (optionalOTP.isEmpty()) {
            throw new RuntimeException("Invalid OTP");
        }

        OTP dbOTP = optionalOTP.get();
        if (dbOTP.isUsed()) {
            throw new RuntimeException("OTP is used");
        }

        dbOTP.setUsed(true);
        otpRepository.save(dbOTP);
    }

    @Override
    public void resetUserPassword(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new RuntimeException();
        }

        try {
            UserRecord.UpdateRequest request = new UserRecord.UpdateRequest(user.getIdentityId())
                    .setPassword(password);
            FirebaseAuth.getInstance().updateUser(request);
        } catch (FirebaseAuthException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public UserDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new RuntimeException();
        }
        return modelMapper.map(user, UserDTO.class);
    }

    @Override
    public User getCurrentUser() {
        JwtAuthenticationToken jwtAuthenticationToken = (JwtAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        String email = jwtAuthenticationToken.getToken().getClaimAsString("email");
        return userRepository.findByEmail(email);
    }

    private Integer generateRandomOTP() {
        Random random = new Random();
        return 1000 + random.nextInt(9000);
    }
}
