package com.CeylonSpehere.TravelApp.service.impl;

import com.CeylonSpehere.TravelApp.dto.*;
import com.CeylonSpehere.TravelApp.entity.User;
import com.CeylonSpehere.TravelApp.entity.VisaApplication;
import com.CeylonSpehere.TravelApp.enums.VisaStatus;
import com.CeylonSpehere.TravelApp.repository.VisaApplicationRepository;
import com.CeylonSpehere.TravelApp.service.UserService;
import com.CeylonSpehere.TravelApp.service.VisaService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class VisaServiceImpl implements VisaService {

    private final VisaApplicationRepository visaApplicationRepository;
    private final UserService userService;
    private final ModelMapper modelMapper;

    @Override
    public void saveEligibilityCriteria(EligibilityCriteriaDTO eligibilityCriteriaDTO) {
        VisaApplication visaApplication = getCurrentUserVisaApplication();
        visaApplication.setNationality(eligibilityCriteriaDTO.getNationality());
        visaApplication.setCountryOfResidence(eligibilityCriteriaDTO.getCountryOfResidence());
        visaApplicationRepository.save(visaApplication);
    }

    @Override
    public void saveUploadDocuments(UploadDocumentsDTO uploadDocumentsDTO) {
        VisaApplication visaApplication = getCurrentUserVisaApplication();
        visaApplication.setPassportBioPage(uploadDocumentsDTO.getPassportBioPage());
        visaApplication.setInvitationLetter(uploadDocumentsDTO.getInvitationLetter());
        visaApplication.setAdditionalDocuments(uploadDocumentsDTO.getAdditionalDocuments());
        visaApplicationRepository.save(visaApplication);
    }

    @Override
    public void savePassportDetails(PassportDetailsDTO passportDetailsDTO) {
        VisaApplication visaApplication = getCurrentUserVisaApplication();
        visaApplication.setPassportNumber(passportDetailsDTO.getPassportNumber());
        visaApplication.setIssuingCountry(passportDetailsDTO.getIssuingCountry());
        visaApplication.setPassportIssueDate(passportDetailsDTO.getPassportIssueDate());
        visaApplication.setPassportExpiryDate(passportDetailsDTO.getPassportExpiryDate());
        visaApplication.setPlaceOfIssue(passportDetailsDTO.getPlaceOfIssue());
        visaApplication.setPassportType(passportDetailsDTO.getPassportType());
        visaApplicationRepository.save(visaApplication);
    }

    @Override
    public void saveContactDetails(ContactDetailsDTO contactDetailsDTO) {
        VisaApplication visaApplication = getCurrentUserVisaApplication();
        visaApplication.setPersonalEmail(contactDetailsDTO.getPersonalEmail());
        visaApplication.setCountryCode(contactDetailsDTO.getCountryCode());
        visaApplication.setMobileNumber(contactDetailsDTO.getMobileNumber());
        visaApplication.setFacebook(contactDetailsDTO.getFacebook());
        visaApplication.setTwitter(contactDetailsDTO.getTwitter());
        visaApplication.setInstagram(contactDetailsDTO.getInstagram());
        visaApplicationRepository.save(visaApplication);
    }

    @Override
    public void saveAdditionalDetails(AdditionalDetailsDTO additionalDetailsDTO) {
        VisaApplication visaApplication = getCurrentUserVisaApplication();
        visaApplication.setDateOfArrivalInSriLanka(additionalDetailsDTO.getDateOfArrivalInSriLanka());
        visaApplication.setPortOfEntry(additionalDetailsDTO.getPortOfEntry());
        visaApplication.setPlaceOfStayDuringVisit(additionalDetailsDTO.getPlaceOfStayDuringVisit());
        visaApplication.setProposedDepartureDate(additionalDetailsDTO.getProposedDepartureDate());
        visaApplication.setAddressLine1(additionalDetailsDTO.getAddressLine1());
        visaApplication.setCity(additionalDetailsDTO.getCity());
        visaApplication.setState(additionalDetailsDTO.getState());
        visaApplication.setZipCode(additionalDetailsDTO.getZipCode());
        visaApplication.setContactCountryCode(additionalDetailsDTO.getContactCountryCode());
        visaApplication.setContactNumberInSriLanka(additionalDetailsDTO.getContactNumberInSriLanka());
        visaApplicationRepository.save(visaApplication);
    }

    @Override
    public VisaApplicationDTO getVisaApplication() {
        VisaApplication visaApplication = getCurrentUserVisaApplication();
        return modelMapper.map(visaApplication, VisaApplicationDTO.class);
    }

    @Override
    public List<VisaApplicationDTO> getAllPendingVisaApplications() {
        return visaApplicationRepository.findAllByStatus(VisaStatus.PENDING).stream()
                .map(visaApplication -> modelMapper.map(visaApplication, VisaApplicationDTO.class))
                .toList();
    }

    @Override
    public void approveVisaApplication(Long applicationId) {
        Optional<VisaApplication> optionalVisaApplication = visaApplicationRepository.findById(applicationId);
        if (optionalVisaApplication.isEmpty()){
            throw new RuntimeException();
        }

        VisaApplication visaApplication = optionalVisaApplication.get();
        visaApplication.setStatus(VisaStatus.APPROVED);
        visaApplicationRepository.save(visaApplication);
    }

    @Override
    public void rejectVisaApplication(Long applicationId, String rejectionReason) {
        Optional<VisaApplication> optionalVisaApplication = visaApplicationRepository.findById(applicationId);
        if (optionalVisaApplication.isEmpty()){
            throw new RuntimeException();
        }

        VisaApplication visaApplication = optionalVisaApplication.get();
        visaApplication.setStatus(VisaStatus.REJECTED);
        visaApplication.setRejectReason(rejectionReason);
        visaApplicationRepository.save(visaApplication);
    }


    private VisaApplication getCurrentUserVisaApplication() {
        User currentUser = userService.getCurrentUser();
        Optional<VisaApplication> optionalVisaApplication =
                visaApplicationRepository.findFirstByUserIdOrderByIdDesc(currentUser.getId());

        if (optionalVisaApplication.isEmpty()) {
            VisaApplication visaApplication = new VisaApplication();
            visaApplication.setUser(currentUser);
            return visaApplication;
        }

        return optionalVisaApplication.get();
    }
}

