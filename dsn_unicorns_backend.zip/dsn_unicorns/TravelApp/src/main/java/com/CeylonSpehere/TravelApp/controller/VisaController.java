package com.CeylonSpehere.TravelApp.controller;

import com.CeylonSpehere.TravelApp.dto.*;
import com.CeylonSpehere.TravelApp.service.VisaService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/visa")
@AllArgsConstructor
public class VisaController {
    private final VisaService visaService;

    @PostMapping("/user/application/eligibility-criteria")
    public ResponseEntity<String> saveEligibilityCriteria(@RequestBody EligibilityCriteriaDTO eligibilityCriteriaDTO) {
        visaService.saveEligibilityCriteria(eligibilityCriteriaDTO);
        return new ResponseEntity<>("Eligibility Criteria saved successfully!", HttpStatus.OK);
    }

    @PostMapping("/user/application/upload-documents")
    public ResponseEntity<String> saveUploadDocuments(@RequestBody UploadDocumentsDTO uploadDocumentsDTO) {
        visaService.saveUploadDocuments(uploadDocumentsDTO);
        return new ResponseEntity<>("Documents uploaded successfully!", HttpStatus.OK);
    }

    @PostMapping("/user/application/passport-details")
    public ResponseEntity<String> savePassportDetails(@RequestBody PassportDetailsDTO passportDetailsDTO) {
        visaService.savePassportDetails(passportDetailsDTO);
        return new ResponseEntity<>("Passport details saved successfully!", HttpStatus.OK);
    }

    @PostMapping("/user/application/contact-details")
    public ResponseEntity<String> saveContactDetails(@RequestBody ContactDetailsDTO contactDetailsDTO) {
        visaService.saveContactDetails(contactDetailsDTO);
        return new ResponseEntity<>("Contact details saved successfully!", HttpStatus.OK);
    }

    @PostMapping("/user/application/additional-details")
    public ResponseEntity<String> saveAdditionalDetails(@RequestBody AdditionalDetailsDTO additionalDetailsDTO) {
        visaService.saveAdditionalDetails(additionalDetailsDTO);
        return new ResponseEntity<>("Additional details saved successfully!", HttpStatus.OK);
    }

    @GetMapping("/user/application/")
    public ResponseEntity<VisaApplicationDTO> getVisaApplication() {
        VisaApplicationDTO visaApplicationDTO = visaService.getVisaApplication();
        return new ResponseEntity<>(visaApplicationDTO, HttpStatus.OK);
    }

    @GetMapping("application/pending")
    public ResponseEntity<List<VisaApplicationDTO>> getAllPendingVisaApplications() {
        List<VisaApplicationDTO> pendingApplications = visaService.getAllPendingVisaApplications();
        return new ResponseEntity<>(pendingApplications, HttpStatus.OK);
    }

    @PutMapping("application/{applicationId}/approve")
    public ResponseEntity<String> approveVisaApplication(@PathVariable Long applicationId) {
        visaService.approveVisaApplication(applicationId);
        return new ResponseEntity<>("Visa application approved successfully!", HttpStatus.OK);
    }

    @PutMapping("application/{applicationId}/reject")
    public ResponseEntity<String> rejectVisaApplication(@PathVariable Long applicationId,
                                                        @RequestParam String rejectionReason) {
        visaService.rejectVisaApplication(applicationId, rejectionReason);
        return new ResponseEntity<>("Visa application rejected successfully!", HttpStatus.OK);
    }
}
