package com.CeylonSpehere.TravelApp.controller;

import com.CeylonSpehere.TravelApp.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
@AllArgsConstructor
public class UserOnboardController {
    private final UserService userService;


}
