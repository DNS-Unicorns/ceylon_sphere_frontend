package com.CeylonSpehere.TravelApp.service;

public interface EmailService {
    void sendEmail(String email, String subject, String body);
}
