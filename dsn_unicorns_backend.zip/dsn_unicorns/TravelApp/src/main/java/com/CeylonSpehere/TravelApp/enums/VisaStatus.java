package com.CeylonSpehere.TravelApp.enums;


public enum VisaStatus {
    PENDING("Pending"),
    APPROVED("Approved"),
    REJECTED("Rejected");


    VisaStatus(String name){this.name = name;}
    private final String name;
}
