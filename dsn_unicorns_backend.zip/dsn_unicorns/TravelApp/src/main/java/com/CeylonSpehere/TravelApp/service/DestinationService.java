package com.CeylonSpehere.TravelApp.service;

import com.CeylonSpehere.TravelApp.dto.requestDto.RequestDestinationDto;

public interface DestinationService {
    public void create(RequestDestinationDto requestDestinationDto);

}
