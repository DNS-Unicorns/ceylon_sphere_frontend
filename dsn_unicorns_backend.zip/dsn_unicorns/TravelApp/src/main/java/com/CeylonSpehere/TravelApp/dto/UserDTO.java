package com.CeylonSpehere.TravelApp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {
    private Long id;
    private String email;
    private String country;
    private String userFavourites;
    private String password;
}
