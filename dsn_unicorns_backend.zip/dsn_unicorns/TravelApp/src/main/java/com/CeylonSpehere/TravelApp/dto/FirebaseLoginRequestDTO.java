package com.CeylonSpehere.TravelApp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class FirebaseLoginRequestDTO {
    private String email;
    private String password;
    private boolean returnSecureToken;
}
