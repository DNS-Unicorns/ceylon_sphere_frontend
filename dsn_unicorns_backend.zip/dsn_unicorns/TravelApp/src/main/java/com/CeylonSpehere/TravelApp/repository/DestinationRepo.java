package com.CeylonSpehere.TravelApp.repository;

public interface DestinationRepo {
}
