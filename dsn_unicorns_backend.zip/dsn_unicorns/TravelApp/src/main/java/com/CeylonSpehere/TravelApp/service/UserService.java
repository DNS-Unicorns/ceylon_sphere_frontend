package com.CeylonSpehere.TravelApp.service;

import com.CeylonSpehere.TravelApp.dto.UserDTO;
import com.CeylonSpehere.TravelApp.dto.requestDto.RequestDestinationDto;
import com.CeylonSpehere.TravelApp.entity.User;

public interface UserService {

    String login(String username, String password);

    void create(UserDTO userDTO);

    void initForgotPassword(String email);

    void verifyForgotPasswordOTP(String email, String otp);

    void resetUserPassword(String email, String password);

    UserDTO getUserByEmail(String email);

    User getCurrentUser();
}
