package com.CeylonSpehere.TravelApp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactDetailsDTO {
    private String personalEmail;
    private String countryCode;
    private String mobileNumber;
    private String facebook;
    private String twitter;
    private String instagram;
}
