package com.CeylonSpehere.TravelApp.dto;

import com.CeylonSpehere.TravelApp.enums.VisaStatus;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class VisaApplicationDTO {
    private Long id;
    private String nationality;
    private String countryOfResidence;
    private String visaType;
    private String visaCategory;
    private String purposeOfTravel;
    private String subVisaType;
    private String typeOfTravelDocument;

    private String passportBioPage;
    private String invitationLetter;
    private String additionalDocuments;

    private String passportNumber;
    private String issuingCountry;
    private LocalDate passportIssueDate;
    private LocalDate passportExpiryDate;
    private String placeOfIssue;
    private String passportType;

    private String personalEmail;
    private String countryCode;
    private String mobileNumber;
    private String facebook;
    private String twitter;
    private String instagram;

    private LocalDate dateOfArrivalInSriLanka;
    private String portOfEntry;
    private String placeOfStayDuringVisit;
    private LocalDate proposedDepartureDate;
    private String addressLine1;
    private String city;
    private String state;
    private String zipCode;
    private String contactCountryCode;
    private String contactNumberInSriLanka;

    private VisaStatus status;
    private String rejectReason;
}
