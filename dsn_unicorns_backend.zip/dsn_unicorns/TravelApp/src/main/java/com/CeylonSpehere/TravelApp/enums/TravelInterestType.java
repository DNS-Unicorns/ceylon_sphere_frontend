package com.CeylonSpehere.TravelApp.enums;

public enum TravelInterestType {
    BEACHES,
    MOUNTAINS,
    CITIES,
    HISTORICAL_SITES,
    ADVENTURE,
    RELAXATION,
    CULTURE,
    NATURE
}
