package com.CeylonSpehere.TravelApp.repository;

import com.CeylonSpehere.TravelApp.entity.User;
import com.CeylonSpehere.TravelApp.entity.VisaApplication;
import com.CeylonSpehere.TravelApp.enums.VisaStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VisaApplicationRepository extends JpaRepository<VisaApplication, Long> {
    Optional<VisaApplication> findFirstByUserIdOrderByIdDesc(Long userId);

    List<VisaApplication> findAllByStatus(VisaStatus status);

}
